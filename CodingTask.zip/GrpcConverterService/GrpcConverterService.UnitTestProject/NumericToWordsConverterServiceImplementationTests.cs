using GrpcNumericToWordsConverterService.ServiceImplementation;
using Xunit;

namespace GrpcConverterService.UnitTestProject
{
    public class NumericToWordsConverterServiceImplementationTests
    {
        /// <summary>
        /// Positive case for numbers
        /// </summary>
        [Fact]
        public void ConvertNumberToWordsUntillThousandTest1()
        {
            NumericToWordsConverterServiceImplementation testclass = new NumericToWordsConverterServiceImplementation();
            string wordResult = testclass.ConvertNumberToWordsUntillThousand(200);
            Assert.Equal("two hundred ",wordResult);
        }

        /// <summary>
        /// Positive case for numbers
        /// </summary>
        [Fact]
        public void ConvertNumberToWordsUntillThousandTest2()
        {
            NumericToWordsConverterServiceImplementation testclass = new NumericToWordsConverterServiceImplementation();
            string wordResult = testclass.ConvertNumberToWordsUntillThousand(210);
            Assert.Equal("two hundred ten", wordResult);
        }

        /// <summary>
        /// Positive case for numbers
        /// </summary>
        [Fact]
        public void ConvertNumberToWordsUntillThousandTest3()
        {
            NumericToWordsConverterServiceImplementation testclass = new NumericToWordsConverterServiceImplementation();
            string wordResult = testclass.ConvertNumberToWordsUntillThousand(219);
            Assert.Equal("two hundred nineteen", wordResult);
        }

        /// <summary>
        /// Positive case for numbers
        /// </summary>
        [Fact]
        public void ConvertNumberToWordsUntillThousandTest4()
        {
            NumericToWordsConverterServiceImplementation testclass = new NumericToWordsConverterServiceImplementation();
            string wordResult = testclass.ConvertNumberToWordsUntillThousand(225);
            Assert.Equal("two hundred twenty-five", wordResult);
        }

        /// <summary>
        /// To check alphabets
        /// </summary>
        [Fact]
        public void ConvertNumberToWordsUntillThousandTestInvalidaCharacters()
        {
            NumericToWordsConverterServiceImplementation testclass = new NumericToWordsConverterServiceImplementation();
            string wordResult = testclass.NumberToWords("abc");
            Assert.Equal(string.Empty, wordResult);
        }
    }
}