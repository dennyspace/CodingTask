﻿using Grpc.Core;
using System;
using System.Threading.Tasks;
using System.Xml;

namespace ConverterUI
{
    public class ServiceCommunicationHandler
    {
        #region Variables
        //Client connection variables
        private Channel clientChannel;
        private NumericToWordsConverterService.Generated.NumericToWordsConverterService.NumericToWordsConverterServiceClient clientNumericToWordsConverterService;

        //Client connection data
        public const string defaultIP = "localhost";
        public const int defaultPort = 11111;

        private string clientIP = defaultIP;
        private int clientPort = defaultPort;

        #endregion

        #region Methods

        /// <summary>
        /// Load connection credentials and Initialize the server communication
        /// </summary>
        public void Initialize()
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("DataAccessLayer\\ConnectionData.xml");
                XmlNodeList elemList = doc.GetElementsByTagName("ConnectionData");
                if (elemList.Count > 0)
                {
                    clientIP = elemList[0].Attributes["ip"].Value;
                    clientPort = Convert.ToInt32(elemList[0].Attributes["port"].Value);
                }
                else
                {
                    clientIP = defaultIP;
                    clientPort = defaultPort;
                }
            }
            catch (Exception)
            {
                return;
            }
            clientChannel = new Channel(clientIP, clientPort, ChannelCredentials.Insecure);
            clientNumericToWordsConverterService = new NumericToWordsConverterService.Generated.NumericToWordsConverterService.NumericToWordsConverterServiceClient(clientChannel);
        }

        /// <summary>
        /// Ensure client connection is established
        /// </summary>
        private void EnsureClientCreated()
        {
            if (IsClientReady())
                return;

            clientChannel = new Channel(clientIP, clientPort, ChannelCredentials.Insecure);
            clientNumericToWordsConverterService = new NumericToWordsConverterService.Generated.NumericToWordsConverterService.NumericToWordsConverterServiceClient(clientChannel);

        }

        /// <summary>
        /// Checks if client is already in connected state
        /// </summary>
        /// <returns></returns>
        private bool IsClientReady()
        {
            if (clientChannel != null && clientNumericToWordsConverterService != null && clientChannel.State == ChannelState.Ready)
                return true;
            return false;
        }

        /// <summary>
        /// Gets the converted value from service
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<string> GetConvertedValueInWords(string input)
        {
            try
            {
                EnsureClientCreated();

                var data = new NumericToWordsConverterService.Generated.Data() { Str = input };

                var res = await clientNumericToWordsConverterService.ConvertToWordsAsync(data);

                return res.Str;
            }
            catch (RpcException)
            {
                return "Server Unavailable";
            }
            catch (Exception)
            {
                return "Exception thrown";
            }
        }
        #endregion
    }
}
