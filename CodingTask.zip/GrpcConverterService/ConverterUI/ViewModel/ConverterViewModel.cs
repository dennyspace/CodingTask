﻿using GrpcCommon;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace ConverterUI
{
    /// <summary>
    /// Viewmodel class to handle logic for ConverterView xaml
    /// </summary>
    public class ConverterViewModel :ViewModelBase
    {
        #region Variables       
        //Data object for input value
        private readonly ConversionData conversionData = new ConversionData();

        private readonly ServiceCommunicationHandler serviceCommunicationHandler;

        #endregion

        #region Constructor
        public ConverterViewModel()
        {
            ConvertedValueHistory = new ObservableCollection<string>();
            serviceCommunicationHandler = new ServiceCommunicationHandler();
            serviceCommunicationHandler.Initialize();
        }
        #endregion

        #region Properties and Events      

        /// <summary>
        /// Input Value
        /// </summary>
        public string NumericValueToConvert
        {
            get { return conversionData.StringToConvert; }
            set 
            {
                conversionData.StringToConvert = value;
                OnPropertyChanged();
            }
        }

        private string convertedResult;

        /// <summary>
        /// Result value
        /// </summary>
        public string ConvertedResult
        {
            get { return convertedResult; }
            set
            {
                convertedResult = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<string> convertedValueHistory;

        /// <summary>
        /// Conversion History
        /// </summary>
        public ObservableCollection<string> ConvertedValueHistory
        {
            get { return convertedValueHistory; }
            set
            {
                convertedValueHistory = value;
                OnPropertyChanged();
            }
        }

        #endregion
       
        #region ICommand variables
        private ICommand mConverter;
        public ICommand ConvertTextCommand
        {
            get 
            {
                if(mConverter == null)
                    mConverter = new DelegateCommand(ConvertText);
                return mConverter;
            }
        }
        #endregion

        #region Methods

        /// <summary>
        /// Executes server call and wait for results
        /// </summary>
        private async void ConvertText()
        {
            string validationError = conversionData.IsValidInput();
            if (validationError != string.Empty)
            {
                ConvertedResult = validationError;
                return;
            }
            string trimmedInput = NumericValueToConvert.Replace(" ", string.Empty);
            string result = await serviceCommunicationHandler.GetConvertedValueInWords(trimmedInput);
            if (result != null)
            {
                ConvertedResult = result;
                if(ConvertedValueHistory.Count>50)
                    ConvertedValueHistory.RemoveAt(0);
                ConvertedValueHistory.Add(trimmedInput+": "+result);
            }
        }
        
        #endregion        
    }   
}
