﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ConverterUI
{
    /// <summary>
    /// Base class for view models
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        #region INotifyPropertxChanged

        public event PropertyChangedEventHandler PropertyChanged;
        /// <summary>
        /// when the Property modifies it Raises OnPropertychangedEvent
        /// </summary>
        /// <param name="name">Property name represented by String</param>
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        #endregion
    }
}
