﻿using System.Globalization;
using System.Windows.Controls;

namespace ConverterUI
{
    #region Validation rules
    /// <summary>
    /// Validation rule to inform user about double spaces or double comma
    /// </summary>
    public class OnlyDigitsValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var validationResult = new ValidationResult(true, null);

            if (value != null)
            {
                if (!string.IsNullOrEmpty(value.ToString()))
                {
                    string input = value.ToString();
                    if (input.Contains(",,") || input.Contains("  "))
                    {
                        validationResult = new ValidationResult(false, "Illegal Characters, Please check the input");
                    }
                }
            }

            return validationResult;
        }
    }
    #endregion
}
