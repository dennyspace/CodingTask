﻿using System;
using System.Windows.Input;

namespace ConverterUI
{
    #region Command Class
    public class DelegateCommand : ICommand
    {
        #region Variables
        //Command action
        private readonly Action _action;
        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="action"></param>
        public DelegateCommand(Action action)
        {
            _action = action;
        }

        #endregion

        #region Properties and Events


#pragma warning disable 67
        //Can execute changed for the command
        public event EventHandler CanExecuteChanged;
#pragma warning restore 67

        #endregion

        #region Methods

        /// <summary>
        /// Execute action
        /// </summary>
        /// <param name="parameter"></param>
        public void Execute(object parameter)
        {
            _action();
        }

        /// <summary>
        /// Can execute the command
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public bool CanExecute(object parameter)
        {
            return true;
        }

        #endregion

    }
    #endregion
}
