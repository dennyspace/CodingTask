﻿

namespace GrpcCommon
{
    public class ConversionData
    {
        #region Properties and Events       

        private string stringToConvert;

        /// <summary>
        /// Input Value
        /// </summary>
        public string StringToConvert
        {
            get { return stringToConvert; }
            set
            {
                stringToConvert = value;                
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Validates the input string
        /// </summary>
        /// <returns>error. If valid error is empty</returns>
        public string IsValidInput()
        {
            string errorMessage = string.Empty;
            if (StringToConvert.Length == 0)
            {
                errorMessage = "Enter a value";
                return errorMessage;
            }
            string trimmedValue = StringToConvert.Replace(" ", string.Empty);
            if (trimmedValue.Contains(",,") || trimmedValue.Contains("  "))
            {
                errorMessage = "Illegal input data";
                return errorMessage;
            }
            if (trimmedValue.Contains(','))
            {
                string[] dollarcentArray = trimmedValue.Split(',');
                if (dollarcentArray[0].Length > 9)
                {
                    errorMessage = "Maximum dollar value is 999999999";
                    if (dollarcentArray[0].StartsWith("00"))
                        errorMessage = "Cannot start with multiple zeros";
                    return errorMessage;
                }
                else if (dollarcentArray[1].Length > 2)
                {
                    errorMessage = "Maximum cent value is 99";
                    return errorMessage;
                }
            }
            else if (trimmedValue.Length > 9)
            {
                errorMessage = "Maximum value is 999999999";
                if (trimmedValue.StartsWith("00"))
                    errorMessage = "Cannot start with multiple zeros";
                return errorMessage;
            }
            else if (trimmedValue.StartsWith("00"))
            {
                errorMessage = "Cannot start with multiple zeros";
                return errorMessage;
            }
            return errorMessage;
        }

        #endregion
    }
}
