﻿using Grpc.Core;
using NumericToWordsConverterService.Generated;

namespace GrpcNumericToWordsConverterService.ServiceImplementation
{
    public class NumericToWordsConverterServiceImplementation: NumericToWordsConverterService.Generated.NumericToWordsConverterService.NumericToWordsConverterServiceBase
    {
        #region Constants
        private string [] unitsMap = new string[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
        private string [] tensMap = new string[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };
        #endregion

        #region Service implementation overrides
        /// <summary>
        /// Override method for service implementation
        /// </summary>
        /// <param name="request"> request object</param>
        /// <param name="context">server context</param>
        /// <returns></returns>
        public override Task<Data> ConvertToWords(Data request, ServerCallContext context)
        {
            var response = new Data() { Str = NumberToWords(request.Str) };
            return Task.FromResult(response);
        }
        #endregion

        #region Methods
        /// <summary>
        /// Conversion logic for converting the numeric string
        /// to words format
        /// </summary>
        /// <param name="number">input number</param>
        /// <returns>returns in word format</returns>
        public string NumberToWords(string number)
        {
            try
            {
                if (string.IsNullOrEmpty(number) || !IsDigitsandCommaOnly(number))
                    return string.Empty;
                string[] dollarsCentsArray = number.Split(',');
                if(dollarsCentsArray.Length > 2)
                    return string.Empty;
                string numberToWords = "";
                //Checks for millions and recurse
                if (dollarsCentsArray[0].Length > 6)
                {
                    string dollarNumber = dollarsCentsArray[0];
                    int millionDigits = Convert.ToInt32(dollarNumber.Substring(0, dollarNumber.Length - 6));
                    numberToWords += ConvertNumberToWordsUntillThousand(millionDigits) + " million ";
                    int thousandDigits = Convert.ToInt32(dollarNumber.Substring(dollarNumber.Length - 6, 3));
                    if (thousandDigits != 0)
                        numberToWords += ConvertNumberToWordsUntillThousand(thousandDigits) + " thousand ";
                    int hundredthDigits = Convert.ToInt32(dollarNumber.Substring(dollarNumber.Length - 3));
                    if (hundredthDigits != 0)
                        numberToWords += ConvertNumberToWordsUntillThousand(hundredthDigits);
                    numberToWords += " dollars";
                    numberToWords = UpdateCentsValue(dollarsCentsArray, numberToWords);
                    return numberToWords;
                }
                //Checks for thousands and recurse
                else if (dollarsCentsArray[0].Length > 3)
                {
                    string dollarNumber = dollarsCentsArray[0];
                    int thousandDigits = Convert.ToInt32(dollarNumber.Substring(0, dollarNumber.Length - 3));
                    numberToWords += ConvertNumberToWordsUntillThousand(thousandDigits) + " thousand ";
                    int hundredthDigits = Convert.ToInt32(dollarNumber.Substring(dollarNumber.Length - 3));
                    if(hundredthDigits != 0)
                        numberToWords += ConvertNumberToWordsUntillThousand(hundredthDigits) ;
                    numberToWords += " dollars";
                    numberToWords = UpdateCentsValue(dollarsCentsArray, numberToWords);
                    return numberToWords;
                }
                //Below thousand handled here
                else
                {
                    string dollarNumber = dollarsCentsArray[0];
                    int hundredthDigits = Convert.ToInt32(dollarNumber);
                    if (hundredthDigits == 1)
                    {
                        numberToWords += "One dollar";
                        numberToWords = UpdateCentsValue(dollarsCentsArray, numberToWords);
                        return numberToWords ;
                    }
                    numberToWords += ConvertNumberToWordsUntillThousand(hundredthDigits) + " dollars"; ;
                    numberToWords = UpdateCentsValue(dollarsCentsArray, numberToWords);
                    return numberToWords;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return string.Empty;
            }
            
        }

        /// <summary>
        /// Gets the cents value into words
        /// </summary>
        /// <param name="dollarsCentsArray"></param>
        /// <param name="numberToWords"></param>
        /// <returns></returns>
        private string UpdateCentsValue(string[] dollarsCentsArray, string numberToWords)
        {
            if (dollarsCentsArray.Length == 2)
            {
                int cents = Convert.ToInt32(dollarsCentsArray[1]);
                if (dollarsCentsArray[1].Length < 2)
                    numberToWords += " and " + ConvertNumberToWordsUntillThousand(cents * 10) + " cents";
                else
                {
                    if (cents == 1)
                        numberToWords += " and " + ConvertNumberToWordsUntillThousand(cents) + " cent";
                    else
                        numberToWords += " and " + ConvertNumberToWordsUntillThousand(cents) + " cents";
                }
            }

            return numberToWords;
        }

        /// <summary>
        /// Gets the numeric representation for numbers less than 1000
        /// </summary>
        /// <param name="number">input number</param>
        /// <returns></returns>
        public string ConvertNumberToWordsUntillThousand(int number)
        {
            try
            {
                string words = "";
                if (number > 999)
                    return string.Empty;
                if (number > 99)
                {
                    int hundredthDigit = number / 100;
                    words += unitsMap[hundredthDigit] + " hundred ";
                    int twoDigitNumber = number % (hundredthDigit * 100);
                    if (number % 100 != 0 && twoDigitNumber > 19)
                    {
                        words += ConvertNumberToWordsUntillThousand(twoDigitNumber);
                    }
                    else if (twoDigitNumber > 0)
                        words += ConvertNumberToWordsUntillThousand(twoDigitNumber);
                    return words;
                }
                if (number > 19)
                {
                    words += tensMap[number / 10];
                    if (number % 10 != 0)
                        words += "-" + ConvertNumberToWordsUntillThousand(number % 10);
                    return words;
                }
                else
                    return unitsMap[number];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return string.Empty;
            }
        }

        /// <summary>
        /// Checks if incoming string has only digits and commas
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private bool IsDigitsandCommaOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                {
                    if (c == ',')
                        continue;
                    return false;
                }
            }

            return true;
        }
        #endregion
    }
}
