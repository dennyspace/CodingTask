﻿// See https://aka.ms/new-console-template for more information
using GrpcNumericToWordsConverterService;

ConverterServer server = new ConverterServer();
server.StartServer();
Console.WriteLine("Converter Server is running");
Console.ReadKey();
