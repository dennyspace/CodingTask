﻿using Grpc.Core;
using GrpcNumericToWordsConverterService.ServiceImplementation;
using System.Xml;

namespace GrpcNumericToWordsConverterService
{
    public class ConverterServer
    {
        #region Variables
        private readonly Server converterServer;

        //Server connection data
        private string serverIP = defaultIP;
        private int serverPort = defaultPort;

        public const string defaultIP = "localhost";
        public const int defaultPort = 11111;

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor 
        /// </summary>
        public ConverterServer()
        {
            Initialize();
            converterServer = new Server()
            {
                Services = { NumericToWordsConverterService.Generated.NumericToWordsConverterService.BindService(new NumericToWordsConverterServiceImplementation()) },
                Ports = { new ServerPort(serverIP, serverPort, ServerCredentials.Insecure) }
            };
        }
        #endregion

        #region Methods

        /// <summary>
        /// Loads connection credentials
        /// </summary>
        public void Initialize()
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("ServerConnectionData.xml");
                XmlNodeList elemList = doc.GetElementsByTagName("ConnectionData");
                if (elemList.Count > 0)
                {
                    serverIP = elemList[0].Attributes["ip"].Value;
                    serverPort = Convert.ToInt32(elemList[0].Attributes["port"].Value);
                }
                else
                {
                    serverIP = defaultIP;
                    serverPort = defaultPort;
                }
            }
            catch (Exception)
            {
                return;
            }
        }
        /// <summary>
        /// Starts the server
        /// </summary>
        public void StartServer()
        {
            try
            {
                if (converterServer == null)
                    return;
                converterServer.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        /// <summary>
        /// Server shutdown
        /// </summary>
        /// <returns></returns>
        public async Task ShutDownAsync()
        {
            await converterServer.ShutdownAsync();
        }
        #endregion
    }
}
